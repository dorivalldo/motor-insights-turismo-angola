"""
Nomadix Package Initialization
"""

__version__ = '1.0.0'
__author__ = 'Nomadix Team'
__description__ = 'Dashboard de Insights para Planejamento Turístico em Angola'
